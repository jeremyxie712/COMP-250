package hashMap;

public class HashLinkedList<K, V> {
	/*
	 * Fields
	 */
	private HashNode<K, V> head;

	private Integer size;

	/*
	 * Constructor
	 */

	HashLinkedList() {
		head = null;
		size = 0;
	}

	/*
	 * Add (Hash)node at the front of the linked list
	 */

	public void add(K key, V value) {
		// ADD CODE BELOW HERE
		addFirst(key, value);

		// ADD CODE ABOVE HERE
	}

	/*
	 * Get Hash(node) by key returns the node with key
	 */

	public HashNode<K, V> getListNode(K key) {
		// ADD CODE BELOW HERE
		if (!this.isEmpty()) {
			HashNode<K, V> cur = new HashNode<K, V>(this.head.clone().getKey(), this.head.clone().getValue());
			cur.next = this.head.clone().next;

			while (cur.getNext() != null) {
				if (cur.getKey() == key) {
					return cur;
				}
				cur = cur.next;
			}
		}
		return null;
		// ADD CODE ABOVE HERE
	}

	/*
	 * Remove the head node of the list Note: Used by remove method and next method
	 * of hash table Iterator
	 */

	public HashNode<K, V> removeFirst() {
		// ADD CODE BELOW HERE
		if (this.head == null) {
			return null;
		}
		HashNode<K, V> target = this.head.clone();

		this.head = this.head.next;
		size--;
		return target;
		// ADD CODE ABOVE HERE
	}

	/*
	 * Remove Node by key from linked list
	 */

	public HashNode<K, V> remove(K key) {
		// ADD CODE BELOW HERE
		HashNode<K, V> target = this.head;
		if (head == null) {
			return null;
		}
		if (target.getKey().equals(key)) {
			// System.out.println("removing first");
			return removeFirst();
		}
		while (target.getNext() != null) {
			if (target.next.getKey().equals(key)) {
				HashNode<K, V> node = target.next;
				target.next = target.next.next;
				size--;
				return node;
			}
			target = target.next;

		}

		// ADD CODE ABOVE HERE
		return null; // removing failed
	}

	/*
	 * Delete the whole linked list
	 */
	public void clear() {
		head = null;
		size = 0;
	}
	/*
	 * Check if the list is empty
	 */

	boolean isEmpty() {
		return size == 0 ? true : false;
	}

	int size() {
		return this.size;
	}

	// ADD YOUR HELPER METHODS BELOW THIS
	public void addFirst(K key, V value) {
		HashNode<K, V> newElement = new HashNode<K, V>(key, value);
		if (head == null) {
			head = newElement;
		} else {
			newElement.next = head;
			head = newElement;
		}
		size = size + 1;

		// newElement.next = head;
		// head = newElement;
	}

	public void addBack(K key, V value) {
		HashNode<K, V> newElement = new HashNode<K, V>(key, value);
		size = size + 1;
		if (this.head == null) {
			head = newElement;
			newElement.next = null;
		}
		HashNode<K, V> curNode = this.head;
		while (curNode.getNext() != null) {
			curNode = curNode.next;
		}
		curNode.next = newElement;
		newElement.next = null;
	}

	public HashNode<K, V> getHead() {
		return this.head;
	}

	// ADD YOUR HELPER METHODS ABOVE THIS

}
